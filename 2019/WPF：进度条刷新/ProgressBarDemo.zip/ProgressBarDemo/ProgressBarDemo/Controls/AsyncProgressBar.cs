﻿using ProgressBarDemo.Threading;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ProgressBarDemo.Controls
{
    public class AsyncProgressBar : DispatcherElementContainer<System.Windows.Controls.ProgressBar>
    {
        public AsyncProgressBar()
        {
            Loaded += AsyncProgressBar_Loaded;
        }

        private System.Windows.Controls.ProgressBar ProgressBar => Child;
        private async void AsyncProgressBar_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {
            Loaded -= AsyncProgressBar_Loaded;
            await this.SetChildAsync();
        }

        public double Value
        {
            get
            {
                if (ProgressBar != null)
                {
                    return ProgressBar.Dispatcher.Invoke(() => ProgressBar.Value);
                }
                return 0;
            }
            set
            {
                SetValue(ValueProperty, value);
            }
        }

        // Using a DependencyProperty as the backing store for Value.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ValueProperty =
            DependencyProperty.Register("Value", typeof(double), typeof(AsyncProgressBar), new PropertyMetadata(0.0,new PropertyChangedCallback(OnValueChanged)));

        private static void OnValueChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            (d as AsyncProgressBar).OnValueChanged( Convert.ToDouble(e.NewValue));
        }
        private void OnValueChanged(double value)
        {
            if (ProgressBar != null)
            {
                ProgressBar.Dispatcher.Invoke(() => ProgressBar.Value = value);
            }
        }
    }
}
