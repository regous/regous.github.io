﻿using ProgressBarDemo.Annotations;
using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Threading;

namespace ProgressBarDemo.Threading
{
    public sealed class DispatcherContainer : DispatcherElementContainer<UIElement>
    {
        public async Task SetChildAsync<T>([CanBeNull] Dispatcher dispatcher = null)
            where T : UIElement, new()
        {
            await SetChildAsync(() => new T(), dispatcher);
        }

        //public async Task SetChildAsync<T>(Func<T> @new, [CanBeNull] Dispatcher dispatcher = null)
        //    where T : UIElement
        //{
        //    dispatcher = dispatcher ?? await UIDispatcher.RunNewAsync($"{typeof(T).Name}");
        //    var child = await dispatcher.InvokeAsync(@new);
        //    await SetChildAsync(child);
        //}
    }
}
