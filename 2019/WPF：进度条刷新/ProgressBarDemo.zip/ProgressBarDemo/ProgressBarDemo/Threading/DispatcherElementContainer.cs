﻿using ProgressBarDemo.Annotations;
using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Threading;

namespace ProgressBarDemo.Threading
{
    [ContentProperty(nameof(Child))]
    public abstract class DispatcherElementContainer<T> : FrameworkElement where T : UIElement, new()
    {
        public DispatcherElementContainer()
        {
            _HostVisual = new InteractiveHostVisual();
        }

        private readonly HostVisual _HostVisual;
        private VisualTargetPresentationSource _TargetSource;

        public void Invoke(Action<T> action)
        {
            if (Child != null)
                Child.Dispatcher.Invoke(() => action(Child));
        }

        #region Child

        private bool _IsUpdatingChild;
        [CanBeNull] private T _Child;
        public T Child => _Child;

        public async Task SetChildAsync([CanBeNull] Dispatcher dispatcher = null)
        {
            await SetChildAsync(() => new T(), dispatcher);
        }

        public async Task SetChildAsync(Func<T> @new, [CanBeNull] Dispatcher dispatcher = null)
        {
            dispatcher = dispatcher ?? await UIDispatcher.RunNewAsync($"{typeof(T).Name}");
            var child = await dispatcher.InvokeAsync(@new);
            await SetChildAsync(child);
        }

        public async Task SetChildAsync(T value)
        {
            if (_IsUpdatingChild)
            {
                throw new InvalidOperationException("Child property should not be set during Child updating.");
            }

            _IsUpdatingChild = true;
            try
            {
                await SetChildAsync();
            }
            finally
            {
                _IsUpdatingChild = false;
            }

            async Task SetChildAsync()
            {
                var oldChild = _Child;
                var visualTarget = _TargetSource;

                if (Equals(oldChild, value))
                    return;

                _TargetSource = null;
                if (visualTarget != null)
                {
                    RemoveVisualChild(oldChild);
                    await visualTarget.Dispatcher.InvokeAsync(visualTarget.Dispose);
                }

                _Child = value;

                if (value == null)
                {
                    _TargetSource = null;
                }
                else
                {
                    await value.Dispatcher.InvokeAsync(() =>
                    {
                        _TargetSource = new VisualTargetPresentationSource(_HostVisual)
                        {
                            RootVisual = _Child,
                        };
                    });
                    AddVisualChild(_HostVisual);
                }
                InvalidateMeasure();
            }
        }
        #endregion

        #region Tree & Layout

        protected override Visual GetVisualChild(int index)
        {
            if (index != 0)
                throw new ArgumentOutOfRangeException(nameof(index));
            return _HostVisual;
        }

        protected override int VisualChildrenCount => _Child != null ? 1 : 0;

        protected override Size MeasureOverride(Size availableSize)
        {
            var child = _Child;
            if (child == null)
                return default(Size);

            child.Dispatcher.InvokeAsync(
                () => child.Measure(availableSize),
                DispatcherPriority.Loaded);

            return default(Size);
        }

        protected override Size ArrangeOverride(Size finalSize)
        {
            var child = _Child;
            if (child == null)
                return finalSize;

            child.Dispatcher.InvokeAsync(
                () => child.Arrange(new Rect(finalSize)),
                DispatcherPriority.Loaded);

            return finalSize;
        }

        #endregion

        #region HitTest
        protected override HitTestResult HitTestCore(PointHitTestParameters htp)
        {
            var child = _Child;

            var element = child?.Dispatcher.Invoke(() =>
            {
                double offsetX = 0d, offsetY = 0d;
                if (child is FrameworkElement fe)
                {
                    offsetX = fe.Margin.Left;
                    offsetY = fe.Margin.Top;
                }
                return _Child.InputHitTest(new Point(htp.HitPoint.X - offsetX, htp.HitPoint.Y - offsetY));
            }, DispatcherPriority.Normal);
            if (element == null)
            {
                return null;
            }

            return new PointHitTestResult(this, htp.HitPoint);
        }

        #endregion
    }
}
