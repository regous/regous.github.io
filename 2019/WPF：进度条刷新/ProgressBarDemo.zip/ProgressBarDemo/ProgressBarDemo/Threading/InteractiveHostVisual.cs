﻿using System.Windows.Media;

namespace ProgressBarDemo.Threading
{
    public class InteractiveHostVisual : HostVisual
    {
    }
}
