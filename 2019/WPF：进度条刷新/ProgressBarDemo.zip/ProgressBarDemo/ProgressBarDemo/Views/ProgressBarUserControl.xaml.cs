﻿using System.Windows;
using System.Windows.Controls;

namespace ProgressBarDemo.Views
{
    /// <summary>
    /// ProgressBarUserControl.xaml 的交互逻辑
    /// </summary>
    public partial class ProgressBarUserControl : UserControl,Interfaces.IProgressView
    {
        public ProgressBarUserControl()
        {
            InitializeComponent();
            DataContext = this;
        }

        public double Progress
        {
            get { return (double)GetValue(ProgressProperty); }
            set { SetValue(ProgressProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Progress.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ProgressProperty =
            DependencyProperty.Register("Progress", typeof(double), typeof(ProgressBarUserControl), new PropertyMetadata(0.0));

        public void SetProgress(double progress)
        {
            Progress = progress;
        }

        public virtual void Start()
        {
            
        }
    }
}
