﻿namespace ProgressBarDemo.Views
{
    public class DispatcherBackgroundInvokeUserControl : ProgressBarUserControl
    {
        public override void Start()
        {
            for (int i = 0; i <= 100; i++)
            {
                progressbar.Dispatcher.Invoke(() => Progress = i, System.Windows.Threading.DispatcherPriority.Background);
                //progressbar.Dispatcher.Invoke(() => progressbar.Value = i, System.Windows.Threading.DispatcherPriority.Background);
                System.Threading.Thread.Sleep(30);
            }
            progressbar.Dispatcher.Invoke(() => { }, System.Windows.Threading.DispatcherPriority.Background);
        }
    }
}
