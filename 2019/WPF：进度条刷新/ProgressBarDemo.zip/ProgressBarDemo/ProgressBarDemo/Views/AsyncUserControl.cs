﻿using System;
using System.Threading.Tasks;

namespace ProgressBarDemo.Views
{
    public class AsyncUserControl : ProgressBarUserControl
    {
        public async override void Start()
        {
            var progress = new Progress<double>(value => Progress = value);
            await Task.Run(() =>
            {
                for (int i = 0; i <= 100; i++)
                {
                    ((IProgress<double>)progress).Report(i);
                    System.Threading.Thread.Sleep(30);
                }
            });

            //await Task.Run(() =>
            //{
            //    this.Dispatcher.Invoke((Action)(() =>
            //    {
            //        //some pre-processing before the actual for loop occur
            //        for (int i = 0; i < 100; i++)
            //        {
            //            ((IProgress<double>)progress).Report(i);
            //        }
            //    }));
            //});
        }
    }
}
