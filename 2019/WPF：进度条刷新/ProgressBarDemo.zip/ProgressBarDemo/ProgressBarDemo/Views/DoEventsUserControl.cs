﻿namespace ProgressBarDemo.Views
{
    public class DoEventsUserControl : ProgressBarUserControl
    {
        public override void Start()
        {
            for (int i = 0; i <= 100; i++)
            {
                Progress = i;
                System.Windows.Forms.Application.DoEvents();
                System.Threading.Thread.Sleep(30);
            }
        }
    }
}
