﻿using System.Windows;
using System.Windows.Controls;

namespace ProgressBarDemo.Views
{
    /// <summary>
    /// ThreadProgressBarUserControl.xaml 的交互逻辑
    /// </summary>
    public partial class ThreadProgressBarUserControl : UserControl, Interfaces.IProgressView
    {
        public ThreadProgressBarUserControl()
        {
            InitializeComponent();
            DataContext = this;
        }

        public double Progress
        {
            get { return (double)GetValue(ProgressProperty); }
            set { SetValue(ProgressProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Progress.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ProgressProperty =
            DependencyProperty.Register("Progress", typeof(double), typeof(ThreadProgressBarUserControl), new PropertyMetadata(0.0));

        public void SetProgress(double progress)
        {
            Progress = progress;
        }

        public void Start()
        {
            for (int i = 0; i <= 100; i++)
            {
                Progress = i;
                System.Threading.Thread.Sleep(30);
            }
        }
    }
}
