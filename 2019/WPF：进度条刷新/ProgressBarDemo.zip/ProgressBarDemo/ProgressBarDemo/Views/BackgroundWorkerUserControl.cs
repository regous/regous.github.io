﻿using System.ComponentModel;

namespace ProgressBarDemo.Views
{
    public class BackgroundWorkerUserControl : ProgressBarUserControl
    {
        private BackgroundWorker Worker = null;
        public override void Start()
        {
            Worker = new BackgroundWorker();
            Worker.DoWork += DoWork;
            Worker.ProgressChanged += Worker_ProgressChanged;
            Worker.WorkerReportsProgress = true;
            Worker.RunWorkerAsync();
        }

        private void Worker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            Progress = e.ProgressPercentage;
        }

        private void DoWork(object sender, DoWorkEventArgs e)
        {
            for (int i = 0; i <= 100; i++)
            {
                Worker.ReportProgress(i);
                System.Threading.Thread.Sleep(30);
            }
        }
    }
}
