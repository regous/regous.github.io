﻿namespace ProgressBarDemo.Views
{
    public class NormalUserControl: ProgressBarUserControl
    {
        public override void Start()
        {
            for (int i = 0; i <= 100; i++)
            {
                Progress = i;
                System.Threading.Thread.Sleep(5);
            }
        }
    }
}
