﻿namespace ProgressBarDemo.Interfaces
{
    interface IProgressView
    {
        void Start();
    }
}
