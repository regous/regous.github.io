// DemoArcobjects.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include "DemoArcobjects.h"
#include "EsriAuthority.h"
#include "ArcEngineSDK.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// Ψһ��Ӧ�ó������

CWinApp theApp;

using namespace std;

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	HMODULE hModule = ::GetModuleHandle(NULL);

	if (hModule != NULL)
	{
		// ��ʼ�� MFC ����ʧ��ʱ��ʾ����
		if (!AfxWinInit(hModule, NULL, ::GetCommandLine(), 0))
		{
			// TODO:  ���Ĵ�������Է���������Ҫ
			_tprintf(_T("����:  MFC ��ʼ��ʧ��\n"));
			nRetCode = 1;
		}
		else
		{
			// TODO:  �ڴ˴�ΪӦ�ó������Ϊ��д���롣
			::CoInitialize(NULL);
			CEsriAuthority::Object.CheckOut();

			IGeoProcessor2Ptr ipGeoProcessor(CLSID_GeoProcessor);
			IVariantArrayPtr ipVariantArray(CLSID_VarArray);
			ipVariantArray->Add(_variant_t(CComBSTR(_T("D:/NewMDB.mdb/LINE"))));
			ipVariantArray->Add(_variant_t(CComBSTR(_T("D:/NewMDB.mdb/LINE1"))));
			IGeoProcessorResultPtr ipGeoProcessorResult;
			HRESULT res = ipGeoProcessor->Execute(_bstr_t(_T("SplitLine")), ipVariantArray, NULL, &ipGeoProcessorResult);

			IGPMessagesPtr ipGPMessages = NULL;
			ipGeoProcessor->GetReturnMessages(&ipGPMessages);
			if (NULL != ipGPMessages)
			{
				long lMsgCount = 0;
				ipGPMessages->get_Count(&lMsgCount);
				for (long l = 0; l < lMsgCount; l++)
				{
					IGPMessagePtr ipGPMessage;
					ipGPMessages->esriGetMessage(l, &ipGPMessage);
					VARIANT_BOOL vbBool;
					BSTR bstrDescription;
					ipGPMessage->get_Description(&bstrDescription);
					ipGPMessage->IsAbort(&vbBool);
					if (vbBool == VARIANT_TRUE)
					{
						//_ErrorCategory((LPCTSTR)(_bstr_t(bstrDescription, false)));
					}
					ipGPMessage->IsError(&vbBool);
					if (vbBool == VARIANT_TRUE)
					{
						//_ErrorCategory((LPCTSTR)(_bstr_t(bstrDescription, false)));
					}
					ipGPMessage->IsInformational(&vbBool);
					if (vbBool == VARIANT_TRUE)
					{
						//_InfoCategory((LPCTSTR)(_bstr_t(bstrDescription, false)));
					}
					ipGPMessage->IsWarning(&vbBool);
					if (vbBool == VARIANT_TRUE)
					{
						//_WarnCategory((LPCTSTR)(_bstr_t(bstrDescription, false)));
					}
					::SysFreeString(bstrDescription);
				}
			}

			CEsriAuthority::Object.Release();
			::CoUninitialize();
		}
	}
	else
	{
		// TODO:  ���Ĵ�������Է���������Ҫ
		_tprintf(_T("����:  GetModuleHandle ʧ��\n"));
		nRetCode = 1;
	}

	return nRetCode;
}
