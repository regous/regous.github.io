#pragma once
#include <map>
//ArcGISVsersion.dll
#import "libid:6FCCEDE0-179D-4D12-B586-58C88D26CA78" no_namespace raw_interfaces_only no_implementation rename("esriProductCode", "esriVersionProductCode") rename("VersionManager","esriVersionManager")
//<esriSystem.olb>
#import "libid:5E1F7BC3-67C5-4AEE-8EC6-C4B73AAC42ED" raw_interfaces_only, raw_native_types, no_namespace, named_guids exclude("OLE_COLOR", "OLE_HANDLE", "VARTYPE", "IStatusBar", "IStream","ISequentialStream","_ULARGE_INTEGER","_LARGE_INTEGER","tagSTATSTG","_FILETIME","tagRECT","IPersist","IPersistStream","ISupportErrorInfo","IErrorInfo") rename("GetObject", "esriGetObject") rename("min","esriMin") rename("max","esriMax")
//�����ں�̨�Ŀ���ʹ�ã���˿�����չ���������ǲ�Ӧ�õ����Ի���;
class CEsriAuthority
{
public: 
	static CEsriAuthority Object;
private:
	CEsriAuthority(void);
	~CEsriAuthority(void);
public:
	BOOL CheckOut();
	void Release();
private:
	BOOL SetArcGisVersion(esriVersionProductCode* lsVersionProductCode=NULL, int count = 0);
	BOOL Initialize();
	BOOL InitializeLicense(esriLicenseProductCode* lsLicenseProductCode = NULL, int count = 0);
	BOOL InitializeExtension(esriLicenseExtensionCode* lsLicenseExtensionCode = NULL, int count = 0);
	void GetArcGISVersion();
private:
	IAoInitializePtr m_ipAoInitialize;
private:
	CString m_strInstallPath; //ArcGIS�İ�װ·��
	CString m_strVersionName; //���� 10.2
	esriVersionProductCode m_eProductCode;
private:
	esriLicenseProductCode m_eCurrentProductCode; //��ǰ��ȡ��Ȩ�޵ȼ�
	std::map<esriLicenseExtensionCode, esriLicenseStatus> m_mapExtensionStatus; //CheckOut����չ;
};
