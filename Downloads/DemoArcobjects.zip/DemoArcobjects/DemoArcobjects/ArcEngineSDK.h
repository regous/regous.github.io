#pragma warning(push)
#pragma warning(disable: 4192)
#pragma warning(disable: 4146)
#pragma warning(disable: 4278)

#import <esriFrameWork.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids rename("UINT_PTR", "esriUINT_PTR") rename("ICommand", "esriICommand") rename("IDocument", "esriIDocument")
#import <esriEngineCore.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids
#import <esriSystemUtility.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids 
#import <esriSystem.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids exclude("OLE_COLOR", "OLE_HANDLE", "VARTYPE", "IStatusBar") rename("GetObject", "esriGetObject")
#import <esriSystemUI.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids exclude("ICursor", "IProgressDialog") rename("ICommand", "esriICommand")
#import <esriControls.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids 
#import <esriGeometry.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids  rename("IParameter", "esriIParameter")  rename("ISegment", "esriISegment") 
#import <esriGeoDatabaseUI.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids exclude("IViewers3D") rename("GetMessage", "esriGetMessage") rename("IRow", "esriIRow") rename("ICursor", "esriICursor") rename("IRelationship", "esriIRelationship") rename ("Field", "Field") rename ("Fields", "Fields") /*rename("VersionManager","esriVersionManager")*/ exclude("VersionManager")
#import <esriGeoDatabase.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids exclude("IViewers3D") rename("GetMessage", "esriGetMessage") rename("IRow", "esriIRow") rename("ICursor", "esriICursor") rename("IRelationship", "esriIRelationship") rename ("Field", "Field") rename ("Fields", "Fields") rename("Record","esriRecord") exclude("IRecord")
#import <esriDisplay.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids rename("RGB", "esriRGB") rename("CMYK", "esriCMYK") rename("ResetDC", "esriResetDC") rename("DrawText", "esriDrawText") exclude("ITransformation")
#import <esriDisplayUI.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids rename("RGB", "esriRGB") rename("CMYK", "esriCMYK") rename("ResetDC", "esriResetDC") rename("DrawText", "esriDrawText") exclude("ITransformation")
#import <esriDataSourcesRaster.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids rename("IThreadedJob", "esriIThreadedJob")
#import <esriCarto.olb> raw_interfaces_only raw_native_types no_namespace named_guids exclude("IInvalidArea","IFillSymbol", "UINT_PTR") rename("ITableDefinition", "EsriITableDefinition") rename("IRow", "esriIRow") rename("IThreadedJob", "esriIThreadedJob")
#import <esriCartoUI.olb> raw_interfaces_only raw_native_types no_namespace named_guids exclude("IInvalidArea","IFillSymbol", "UINT_PTR") rename("ITableDefinition", "EsriITableDefinition")

#import <esriServer.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids  rename("GetObject", "esriGetObject")
#import <esriNetworkAnalysis.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids 
#import <esriOutput.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids 
#import <esriGISClient.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids 
#import <esriGeoDatabaseDistributed.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids
#import <esriGeoDatabaseDistributedUI.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids 
#import <esriGeoAnalyst.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids 

#import <esriDataSourcesOleDB.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids 
#import <esriDataSourcesGDB.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids 
#import <esriDataSourcesFile.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids exclude("OLE_HANDLE", "OLE_COLOR") 
#import <esri3DAnalyst.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids exclude("IMarkerSymbol", "ILineSymbol", "IFillSymbol") 
#import <esriGeoStatisticalAnalyst.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids
#import <esriGlobeCore.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids exclude("IViewers3D")
#import <esriSpatialAnalyst.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids
#import <esriCatalog.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids
#import <esriCatalogUI.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids
#import <esriArcMap.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids
#import <esriArcMapUI.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids
#import <esriEditor.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids rename ("IEditTool","esriIEditTool") rename ("EditTool","esriEditTool")
#import <esriGeoProcessing.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids
#import <esriOutputUI.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids
#import <esriEditorExt.olb> raw_interfaces_only, raw_native_types, no_namespace, named_guids
#define CLSID_Parameter esriCLSID_Parameter


#pragma warning(pop) 


