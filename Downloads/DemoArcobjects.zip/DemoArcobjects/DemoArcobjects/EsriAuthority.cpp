#include "StdAfx.h"
#include "EsriAuthority.h"

CEsriAuthority CEsriAuthority::Object;

CEsriAuthority::CEsriAuthority(void)
{
}

CEsriAuthority::~CEsriAuthority(void)
{
}
BOOL CEsriAuthority::SetArcGisVersion(esriVersionProductCode* lsVersionProductCode, int count)
{
	bool bFlag = false;
	bool bRes = false;
	if (lsVersionProductCode == NULL)
	{
		count = 6;
		lsVersionProductCode = new esriVersionProductCode[count];
		lsVersionProductCode[0] = esriArcGISDesktop;
		lsVersionProductCode[1] = esriArcGISEngine;
		lsVersionProductCode[2] = esriArcGISReader;
		lsVersionProductCode[3] = esriArcGISExplorer;
		lsVersionProductCode[4] = esriArcGISServer;
		lsVersionProductCode[5] = esriArcGIS;
		bFlag = true;
	}
	HRESULT hr;
	IArcGISVersionPtr ipVersion;
	hr = ipVersion.CreateInstance(__uuidof(esriVersionManager)); //
	if (hr == S_OK&&ipVersion != NULL)
	{
		for (int i = 0; i < count; i++)
		{
			VARIANT_BOOL vb = VARIANT_FALSE;
			hr = ipVersion->LoadVersion(lsVersionProductCode[i], CComBSTR(m_strVersionName), &vb);
			if (SUCCEEDED(hr) && vb == VARIANT_TRUE)
			{
				bRes = true;
				break;
			}
		}
	}
	if (bFlag)
		delete[] lsVersionProductCode;

	return bRes ? TRUE : FALSE;
}

BOOL CEsriAuthority::Initialize()
{
	GetArcGISVersion();

	if (FALSE == SetArcGisVersion(NULL))
		return FALSE;

	if (NULL == m_ipAoInitialize)
	{
		HRESULT hr = m_ipAoInitialize.CreateInstance(CLSID_AoInitialize);
		if (FAILED(hr))
		{
			return FALSE;
		}
	}
	if (FALSE == InitializeLicense())
	{
		return FALSE;
	}
	InitializeExtension();
	return TRUE;
}
BOOL CEsriAuthority::InitializeLicense(esriLicenseProductCode* lsLicenseProductCode, int count)
{
	bool bFlag = false;
	bool bRes = false;
	if (lsLicenseProductCode == NULL)
	{
		count = 6;
		lsLicenseProductCode = new esriLicenseProductCode[count];
		lsLicenseProductCode[0] = esriLicenseProductCodeAdvanced;
		lsLicenseProductCode[1] = esriLicenseProductCodeEngineGeoDB;
		lsLicenseProductCode[2] = esriLicenseProductCodeArcServer;
		lsLicenseProductCode[3] = esriLicenseProductCodeEngine;
		lsLicenseProductCode[4] = esriLicenseProductCodeStandard;
		lsLicenseProductCode[5] = esriLicenseProductCodeBasic;
		bFlag = true;
	}
	HRESULT hr;

	for (int i = 0; i < count; i++)
	{
		esriLicenseStatus licenseStatus = esriLicenseFailure;
		hr = m_ipAoInitialize->IsProductCodeAvailable(lsLicenseProductCode[i], &licenseStatus);
		if (FAILED(hr))
			continue;

		if (licenseStatus == esriLicenseAvailable)
			hr = m_ipAoInitialize->Initialize(lsLicenseProductCode[i], &licenseStatus);
		if (SUCCEEDED(hr) && licenseStatus == esriLicenseCheckedOut)
		{
			m_eCurrentProductCode = lsLicenseProductCode[i];
			bRes = true;
			break;
		}

	}
	if (bFlag)
		delete[] lsLicenseProductCode;
	return bRes ? TRUE : FALSE;
}

BOOL CEsriAuthority::InitializeExtension(esriLicenseExtensionCode* lsLicenseExtensionCode /*= NULL*/, int count /*= 0*/)
{
	bool bFlag = false;
	bool bRes = false;
	if (lsLicenseExtensionCode == NULL)
	{
		count = 49;
		lsLicenseExtensionCode = new esriLicenseExtensionCode[count];
		lsLicenseExtensionCode[0] = esriLicenseExtensionCodeArcPress;
		lsLicenseExtensionCode[1] = esriLicenseExtensionCodeTIFFLZW;
		lsLicenseExtensionCode[2] = esriLicenseExtensionCodeGeoStats;
		lsLicenseExtensionCode[3] = esriLicenseExtensionCodeMrSID;
		lsLicenseExtensionCode[4] = esriLicenseExtensionCodeNetwork;
		lsLicenseExtensionCode[5] = esriLicenseExtensionCode3DAnalyst;
		lsLicenseExtensionCode[6] = esriLicenseExtensionCodeSpatialAnalyst;
		lsLicenseExtensionCode[7] = esriLicenseExtensionCodeStreetMap;
		lsLicenseExtensionCode[8] = esriLicenseExtensionCodeCOGO;
		lsLicenseExtensionCode[9] = esriLicenseExtensionCodeMLE;
		lsLicenseExtensionCode[10] = esriLicenseExtensionCodePublisher;
		lsLicenseExtensionCode[11] = esriLicenseExtensionCodeArcMapServer;
		lsLicenseExtensionCode[12] = esriLicenseExtensionCodeTracking;
		lsLicenseExtensionCode[13] = esriLicenseExtensionCodeBusinessStandard;
		lsLicenseExtensionCode[14] = esriLicenseExtensionCodeArcScan;
		lsLicenseExtensionCode[15] = esriLicenseExtensionCodeBusiness;
		lsLicenseExtensionCode[16] = esriLicenseExtensionCodeSchematics;
		lsLicenseExtensionCode[17] = esriLicenseExtensionCodeSchematicsSDK;
		lsLicenseExtensionCode[18] = esriLicenseExtensionCodeVirtualEarthEng;
		lsLicenseExtensionCode[19] = esriLicenseExtensionCodeVBAExtension;
		lsLicenseExtensionCode[20] = esriLicenseExtensionCodeWorkflowManager;
		lsLicenseExtensionCode[21] = esriLicenseExtensionCodeDesigner;
		lsLicenseExtensionCode[22] = esriLicenseExtensionCodeVector;
		lsLicenseExtensionCode[23] = esriLicenseExtensionCodeDataInteroperability;
		lsLicenseExtensionCode[24] = esriLicenseExtensionCodeProductionMapping;
		lsLicenseExtensionCode[25] = esriLicenseExtensionCodeDataReViewer;
		lsLicenseExtensionCode[26] = esriLicenseExtensionCodeMPSAtlas;
		lsLicenseExtensionCode[27] = esriLicenseExtensionCodeDefense;
		lsLicenseExtensionCode[28] = esriLicenseExtensionCodeNautical;
		lsLicenseExtensionCode[29] = esriLicenseExtensionCodeIntelAgency;
		lsLicenseExtensionCode[30] = esriLicenseExtensionCodeMappingAgency;
		lsLicenseExtensionCode[31] = esriLicenseExtensionCodeAeronautical;
		lsLicenseExtensionCode[32] = esriLicenseExtensionCodeVirtualEarth;
		lsLicenseExtensionCode[33] = esriLicenseExtensionCodeServerStandardEdition;
		lsLicenseExtensionCode[34] = esriLicenseExtensionCodeServerAdvancedEdition;
		lsLicenseExtensionCode[35] = esriLicenseExtensionCodeServerEnterprise;
		lsLicenseExtensionCode[36] = esriLicenseExtensionCodeImageExt;
		lsLicenseExtensionCode[37] = esriLicenseExtensionCodeBingMaps;
		lsLicenseExtensionCode[38] = esriLicenseExtensionCodeBingMapsEng;
		lsLicenseExtensionCode[39] = esriLicenseExtensionCodeDefenseUS;
		lsLicenseExtensionCode[40] = esriLicenseExtensionCodeDefenseINTL;
		lsLicenseExtensionCode[41] = esriLicenseExtensionCodeAGINSPIRE;
		lsLicenseExtensionCode[42] = esriLicenseExtensionCodeRuntimeBasic;
		lsLicenseExtensionCode[43] = esriLicenseExtensionCodeRuntimeStandard;
		lsLicenseExtensionCode[44] = esriLicenseExtensionCodeRuntimeAdvanced;
		lsLicenseExtensionCode[45] = esriLicenseExtensionCodeHighways;
		lsLicenseExtensionCode[46] = esriLicenseExtensionCodeVideo;
		lsLicenseExtensionCode[47] = esriLicenseExtensionCodeBathymetry;
		lsLicenseExtensionCode[48] = esriLicenseExtensionCodeAirports;
		bFlag = true;
	}
	HRESULT hr;

	for (int i = 0; i < count; i++)
	{
		esriLicenseStatus eLicenseStatus = esriLicenseFailure;
		hr = m_ipAoInitialize->IsExtensionCodeAvailable(m_eCurrentProductCode, lsLicenseExtensionCode[i], &eLicenseStatus);
		if (eLicenseStatus == esriLicenseStatus::esriLicenseAvailable)
		{
			hr = m_ipAoInitialize->CheckOutExtension(lsLicenseExtensionCode[i], &eLicenseStatus);
			if (eLicenseStatus == esriLicenseStatus::esriLicenseCheckedOut)
			{
				m_mapExtensionStatus[lsLicenseExtensionCode[i]] = eLicenseStatus;
			}
			bRes = true;
		}
	}
	if (bFlag)
		delete[] lsLicenseExtensionCode;
	return bRes ? TRUE : FALSE;
}

void CEsriAuthority::GetArcGISVersion()
{
	HRESULT hr;
	IArcGISVersionPtr ipVersion;
	hr = ipVersion.CreateInstance(__uuidof(esriVersionManager)); //
	if (FAILED(hr) || ipVersion == NULL)
	{
		return;
	}
	IEnumVersionsPtr ipEnumVer;
	hr = ipVersion->GetVersions(&ipEnumVer);
	if (FAILED(hr) || ipEnumVer == NULL)
	{
		return;
	}
	BSTR bstrVersionName, bstrInstallPath;
	hr = ipEnumVer->Reset();
	while (S_OK == ipEnumVer->Next(&m_eProductCode, &bstrVersionName, &bstrInstallPath))
	{
		m_strInstallPath = bstrInstallPath;
		::SysFreeString(bstrInstallPath);
		m_strVersionName = bstrVersionName;
		::SysFreeString(bstrVersionName);
		break;;
	}
}

BOOL CEsriAuthority::CheckOut()
{
	if (m_ipAoInitialize != NULL)
		return TRUE;
	if (!Initialize())
	{
		return FALSE;
	}
	return TRUE;
}

void CEsriAuthority::Release()
{
	if (m_ipAoInitialize != NULL)
	{
		for (auto iter = m_mapExtensionStatus.begin(); iter != m_mapExtensionStatus.end(); iter++)
		{
			esriLicenseStatus eLicenseStatus;
			m_ipAoInitialize->CheckInExtension(iter->first, &eLicenseStatus);
		}
		m_mapExtensionStatus.clear();
		m_ipAoInitialize->Shutdown();
		m_ipAoInitialize = NULL;
	}
}